/// 注意：本文件由 FruitBuilder 生成和管理，请误手工更改
using Fruit.Web.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using Fruit.Data;
using Fruit.Models;
using Newtonsoft.Json.Linq;

namespace Fruit.Web.Areas.Business.Controllers
{
    public partial class Fw_ObjectionresultController : Controller
    {
        public ActionResult Index(string id = null)        {
            if (id == null)
            {
                // 提供搜索下拉框数据源
                List<ComboItem> MemId;
                using(var db = new LUOLAI1401Context())
                {
                    MemId = db.fw_memberinfo.Select(i=>new ComboItem{ Text = i.realname, Value = "" +  i.memid }).ToList();
                }
                return View(new {dataSource = new {MemId}});
            }
            else
            {
                return View("Edit", id);
            }
        }
        public ActionResult Edit(int id)
        {
            fw_ObjectionResult form = null;
            List<ComboItem> paymentmode = null, resultstatus = null, finalresult = null, MemId = null;
            using(var db = new SysContext())
            {
                paymentmode = db.Database.SqlQuery<ComboItem>("select Text Text, Value Value from sys_code where " + string.Format("{0}", "/*TABLEALIAS*/CodeType='PayKind'")).ToList();
                resultstatus = db.Database.SqlQuery<ComboItem>("select Text Text, Value Value from sys_code where " + string.Format("{0}", "/*TABLEALIAS*/CodeType='ObjState'")).ToList();
                finalresult = db.Database.SqlQuery<ComboItem>("select Text Text, Value Value from sys_code where " + string.Format("{0}", "/*TABLEALIAS*/CodeType='ObjState'")).ToList();
            }
            using(var db = new LUOLAI1401Context())
            {
                MemId = db.fw_memberinfo.Select(i=>new ComboItem{ Text = i.realname, Value = "" + i.memid }).ToList();
                form = db.fw_ObjectionResult.Find(id);
            }
            ViewBag.RowState = 2;
            if (form == null)
            {
                ViewBag.RowState = 1;
                form = new fw_ObjectionResult
                {
                    objectionid = id
                };
            }
            return View(new { form = form, dataSource = new { paymentmode,resultstatus,finalresult,MemId }});
        }

    }
    public partial class Fw_ObjectionresultApiController : ApiController
    {
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]class fw_ObjectionResultListModel {
            public int objectionid { get; set; }
            public string orderid { get; set; }
            public decimal? payment { get; set; }
            public string paymentmode { get; set; }
            public string paymentmode_RefText { get; set; }
            public DateTime? paymentendtime { get; set; }
            public string explain { get; set; }
            public string resultstatus { get; set; }
            public string resultstatus_RefText { get; set; }
            public string resultperson { get; set; }
            public string resultphone { get; set; }
            public string finalresult { get; set; }
            public string finalresult_RefText { get; set; }
            public string MemId { get; set; }
            public string MemId_RefText { get; set; }
        }
        public object Get()
        {
            var sbCondition = new System.Text.StringBuilder();
            SerachCondition.TextBox(sbCondition, "orderid", "a.orderid", "");
            SerachCondition.Dropdown(sbCondition, "MemId", "a.MemId", "");

            if(sbCondition.Length>4) sbCondition.Length-=4;
            var pageReq = new PageRequest();
            using (var db = new LUOLAI1401Context())
            {
                return pageReq.ToPageList<fw_ObjectionResultListModel>(db.Database, "a.objectionid ,a.orderid ,a.payment ,b.Text paymentmode_RefText ,a.paymentmode ,a.paymentendtime ,a.explain ,c.Text resultstatus_RefText ,a.resultstatus ,a.resultperson ,a.resultphone ,d.Text finalresult_RefText ,a.finalresult ,e.realname MemId_RefText ,a.MemId ", "fw_ObjectionResult a LEFT JOIN [SYS_YLW].dbo.sys_code b ON a.paymentmode = b.Value AND (b.CodeType='PayKind') LEFT JOIN [SYS_YLW].dbo.sys_code c ON a.resultstatus = c.Value AND (c.CodeType='ObjState') LEFT JOIN [SYS_YLW].dbo.sys_code d ON a.finalresult = d.Value AND (d.CodeType='ObjState') LEFT JOIN fw_memberinfo e ON a.MemId = e.memid ", sbCondition.ToString(), "a.objectionid", "desc");
            }
        }
        public object Post(JObject post)
        {
            var form = post["form"].ToObject<fw_ObjectionResult>(JsonExtension.FixJsonSerializer);
            using (var db = new LUOLAI1401Context())
            {
                var dbForm = db.fw_ObjectionResult.Find(form.objectionid);
                if (dbForm == null)
                {
                    form.CreateDate = DateTime.Now;
                    form.CreatePerson = (HttpContext.Current.Session["sys_user"] as sys_user).UserName;
                    db.fw_ObjectionResult.Add(form);
                }
                else
                {
                    dbForm.orderid = form.orderid;
                    dbForm.payment = form.payment;
                    dbForm.paymentmode = form.paymentmode;
                    dbForm.paymentendtime = form.paymentendtime;
                    dbForm.explain = form.explain;
                    dbForm.resultstatus = form.resultstatus;
                    dbForm.resultperson = form.resultperson;
                    dbForm.resultphone = form.resultphone;
                    dbForm.finalresult = form.finalresult;
                    dbForm.MemId = form.MemId;
                    dbForm.UpdateDate = form.UpdateDate = DateTime.Now;
                    dbForm.UpdatePerson = form.UpdatePerson = (HttpContext.Current.Session["sys_user"] as sys_user).UserName;
                }
                // 记录多级零时主键对应(key int 为 js 生成的页内全局唯一编号)
                var _id_maps = new Dictionary<int, object[]>();
                db.SaveChanges();
            }
            return new { success = true, form = form };
        }
        public object Delete(string id)
        {
            var _ids = new List<int>();

            using (var db = new LUOLAI1401Context())
            {
                foreach(string _id in id.Split(','))
                {
                    var did = int.Parse(_id);
                    db.fw_ObjectionResult.Remove(r => r.objectionid == did);
                }
                db.SaveChanges();
            }
            return true;
        }
        public object Newobjectionid()
        {
            return new SysSerialServices().GetNewSerial("fw_ObjectionResult");
        }

    }
}
