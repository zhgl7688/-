﻿using System.Web.Mvc;

namespace Fruit.Web.Areas.Rols
{
    public class RolsAreaRegistration : BaseAreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Rols";
            }
        }
    }
}