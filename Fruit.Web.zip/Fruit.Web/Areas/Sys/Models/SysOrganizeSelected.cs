﻿using Fruit.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fruit.Models
{
    public class SysOrganizeRoleSelected : sys_role
    {
        public bool Selected { get; set; }
    }
}