﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fruit.Models
{
    public class SysButtonSelected : sys_button
    {
        public bool Selected { get; set; }
    }
}
