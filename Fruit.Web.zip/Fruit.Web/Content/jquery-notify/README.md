jQuery Notify

**jQuery Notify** is a jQuery plugin that easily displays html notifications.

Please visit [www.vicreative.nl](http://www.vicreative.nl/Projects/Notify) for full documentation.